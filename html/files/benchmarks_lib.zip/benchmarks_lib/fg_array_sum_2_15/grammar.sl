(synth-fun findSum (      ( x1  Int )  ( x2  Int ) )  Int (
	(Start  Int (		x1 x2  
	0 1 (+ Start Start) (- Start Start) (ite B Start Start)
))
	(B Bool (		(and B B) (or B B) (not B) (= Start Start) (<= Start Start) (>= Start Start)
))
	
))

