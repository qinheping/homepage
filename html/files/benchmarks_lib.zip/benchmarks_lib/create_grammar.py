import os
for file in os.listdir("./"):
    if file.endswith(".sl"):
        file_gramamr = str(file[:-3]) +"/grammar.sl"
        print file_gramamr
        if not os.path.exists(os.path.dirname(file_gramamr)):
    	    try:
        	    os.makedirs(os.path.dirname(file_gramamr))
    	    except OSError as exc: # Guard against race condition
       		    if exc.errno != errno.EEXIST:
        		    raise
        f = open(file, "r")
        inputStr = f.read()
        outStr = ""
        isSynth = False
        for line in inputStr.splitlines():
            if "synth-fun" in line:
                isSynth = True
            if "declare-var" in line:
                isSynth = False
            if "define-fun" in line:
                isSynth = False
            if isSynth:
                outStr += line+"\n"
        f.close()
        with open(file_gramamr, "w+") as f_g:
            f_g.write(outStr)
            f_g.close()

