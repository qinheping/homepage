(synth-fun eq1 ( (x Int) (y Int) (z Int) ) Int
(
					(Start  Int (		x y z
	0 1 (+ Start Start) (ite B Start Start)
))
	(B Bool (		(and B B) (or B B) (not B) (= Start Start) (<= Start Start) (>= Start Start)
))
))

