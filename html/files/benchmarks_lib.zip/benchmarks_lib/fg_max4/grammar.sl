(synth-fun max4  (       ( x  Int )  ( y  Int )  ( z  Int )  ( w  Int ) )  Int (
			(Start  Int (		x y z w
	0 1 (+ Start Start) (- Start Start) (ite B Start Start)
))
	(B Bool (		(and B B) (or B B) (not B) (= Start Start) (<= Start Start) (>= Start Start)
))
))


