(synth-fun eq2  (       ( x  Int )  ( y  Int )  ( z  Int )  ( z1  Int ) )  Int (
				(Start  Int (		x y z z1
	0 1 (+ Start Start) (- Start Start) (ite B Start Start)
))
	(B Bool (		(and B B) (or B B) (not B) (= Start Start) (<= Start Start) (>= Start Start)
))
))


