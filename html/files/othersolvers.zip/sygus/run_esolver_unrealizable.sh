
cd solvers/ESolver/bin
for file in ../../../benchmarks/unrealizable/if/*
do
  echo $file >> ../../../results.out
  timeout  600s bash starexec_run_Default "$file" >> ../../../results.out
done

for file in ../../../benchmarks/unrealizable/const/*
do
  echo $file >> ../../../results.out
  timeout  600s bash starexec_run_Default "$file" >> ../../../results.out
done


for file in ../../../benchmarks/unrealizable/plus/*
do
  echo $file >> ../../../results.out
  timeout  600s bash starexec_run_Default "$file" >> ../../../results.out
done

