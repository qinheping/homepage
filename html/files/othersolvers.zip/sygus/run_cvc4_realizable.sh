
cd solvers/CVC4/
for file in ../../benchmarks/realizable/*
do
  echo $file >> ../../results.out
  timeout  600s bash starexec_run_syguscomp2015 "$file" >> ../../results.out
done