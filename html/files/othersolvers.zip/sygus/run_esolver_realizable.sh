
cd solvers/ESolver/bin
for file in ../../../benchmarks/realizable/*
do
  echo $file >> ../../../results.out
  timeout  600s bash starexec_run_Default "$file" >> ../../../results.out
done